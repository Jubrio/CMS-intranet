"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { NAV, afficher } from "@/lib/espace";
import { cn } from "@/lib/utils";
import { useEspace } from "./espace-context";

export function LogoEntreprise({ className }: { className?: string }) {
  const { profil, perso } = useEspace();
  const nom = perso?.nom_entreprise ?? profil.entreprise ?? "";

  if (perso?.logo_url) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={perso.logo_url} alt="" className={cn("size-8 rounded-md object-contain", className)} />;
  }
  return (
    <span
      aria-hidden
      className={cn(
        "grid size-8 place-items-center rounded-md bg-[var(--espace-accent)] text-sm font-semibold text-[var(--espace-accent-fg)]",
        className,
      )}
    >
      {nom.charAt(0).toUpperCase() || "?"}
    </span>
  );
}

export function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const { profil, perso } = useEspace();
  const pathname = usePathname();

  // On ne montre que les entrées auxquelles le rôle a droit (permission + module actif)
  const groupes = NAV.map((g) => ({ ...g, items: g.items.filter((i) => afficher(profil, i)) })).filter(
    (g) => g.items.length > 0,
  );

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-14 shrink-0 items-center gap-2.5 border-b px-4">
        <LogoEntreprise />
        <span className="truncate text-sm font-semibold">{perso?.nom_entreprise ?? profil.entreprise}</span>
      </div>

      <nav aria-label="Navigation principale" className="flex-1 space-y-5 overflow-y-auto px-3 py-4">
        {groupes.map((groupe) => (
          <div key={groupe.titre ?? "principal"}>
            {groupe.titre && (
              <p className="mb-1.5 px-2 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                {groupe.titre}
              </p>
            )}
            <ul className="space-y-0.5">
              {groupe.items.map((item) => {
                const Icone = item.icone;
                const actif = item.href
                  ? item.href === "/espace"
                    ? pathname === "/espace"
                    : pathname === item.href || pathname.startsWith(`${item.href}/`)
                  : false;

                if (!item.href) {
                  return (
                    <li key={item.libelle}>
                      <span
                        aria-disabled="true"
                        className="flex cursor-not-allowed items-center gap-2.5 rounded-lg px-2 py-1.5 text-sm text-muted-foreground/70"
                      >
                        <Icone className="size-4 shrink-0" aria-hidden />
                        <span className="truncate">{item.libelle}</span>
                        <span className="ml-auto rounded-full bg-muted px-1.5 py-0.5 text-[10px] font-medium">
                          Bientôt
                        </span>
                      </span>
                    </li>
                  );
                }

                return (
                  <li key={item.libelle}>
                    <Link
                      href={item.href}
                      onClick={onNavigate}
                      aria-current={actif ? "page" : undefined}
                      className={cn(
                        "relative flex items-center gap-2.5 rounded-lg px-2 py-1.5 text-sm transition-colors outline-none focus-visible:ring-3 focus-visible:ring-ring/50",
                        actif ? "bg-muted font-medium text-foreground" : "text-foreground/80 hover:bg-muted/60",
                      )}
                    >
                      {actif && (
                        <span
                          aria-hidden
                          className="absolute inset-y-1.5 -left-3 w-1 rounded-r-full bg-[var(--espace-accent)]"
                        />
                      )}
                      <Icone className="size-4 shrink-0" aria-hidden />
                      <span className="truncate">{item.libelle}</span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </div>
  );
}
