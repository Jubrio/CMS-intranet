"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ApiError } from "@/lib/api";
import { effacerToken, lireToken } from "@/lib/session";

type Etat<T> = { donnees: T | null; erreur: boolean; chargement: boolean };

// Charge une donnée de l'API pour un bloc du tableau de bord.
// `actif` = false : le bloc n'est pas concerné (permission ou module absent), aucun appel.
// `charger` doit être stable (useCallback) pour éviter de relancer l'appel à chaque rendu.
export function useDonnees<T>(actif: boolean, charger: (token: string) => Promise<T>) {
  const router = useRouter();
  const [etat, setEtat] = useState<Etat<T>>({ donnees: null, erreur: false, chargement: actif });
  const [essai, setEssai] = useState(0);

  useEffect(() => {
    if (!actif) return;
    const token = lireToken();
    if (!token) {
      router.replace("/connexion");
      return;
    }

    let annule = false;
    charger(token)
      .then((donnees) => {
        if (!annule) setEtat({ donnees, erreur: false, chargement: false });
      })
      .catch((err) => {
        if (annule) return;
        if (err instanceof ApiError && err.status === 401) {
          // session expirée pendant l'utilisation
          effacerToken();
          router.replace("/connexion");
          return;
        }
        setEtat({ donnees: null, erreur: true, chargement: false });
      });

    return () => {
      annule = true;
    };
  }, [actif, charger, essai, router]);

  const reessayer = useCallback(() => {
    setEtat({ donnees: null, erreur: false, chargement: true });
    setEssai((n) => n + 1);
  }, []);

  return { ...etat, reessayer };
}
