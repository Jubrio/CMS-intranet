"use client";

import { useCallback, useMemo, type ReactNode } from "react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { Blocks, Building2, FileClock, Users, type LucideIcon } from "lucide-react";
import { api } from "@/lib/api";
import { iconeModule } from "@/lib/module-icons";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useEspace } from "./espace-context";
import { useDonnees } from "./use-donnees";

// ---- Formes des réponses de l'API ------------------------------------------

type PageTotal = { total: number };

type DepartementResume = {
  id: number;
  nom_departement: string;
  nb_employes: number;
  responsable: { id: number; nom: string; prenom: string } | null;
};

type ModuleEtat = {
  code_module: string;
  nom_module: string;
  description_module: string;
  module_obligatoire: boolean;
  actif: boolean;
};

// Types de contenu et module associé (même correspondance que Contenu::MODULES côté Laravel)
const TYPES_CONTENU = [
  { type: "actualite", libelle: "Actualités", module: "actualites" },
  { type: "annonce", libelle: "Annonces", module: "annonces" },
  { type: "article", libelle: "Articles", module: "articles" },
  { type: "note_service", libelle: "Notes de service", module: "notes_service" },
] as const;

const nombre = new Intl.NumberFormat("fr-FR");

// ---- Éléments d'affichage ---------------------------------------------------

function Carte({ children, className }: { children: ReactNode; className?: string }) {
  return <section className={cn("rounded-xl border bg-card p-4 text-card-foreground", className)}>{children}</section>;
}

function Squelette({ className }: { className?: string }) {
  return <div aria-hidden className={cn("animate-pulse rounded-md bg-muted", className)} />;
}

function ErreurBloc({ onReessayer }: { onReessayer: () => void }) {
  return (
    <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
      <span>Impossible de charger cette section.</span>
      <Button variant="outline" size="xs" onClick={onReessayer}>
        Réessayer
      </Button>
    </div>
  );
}

function Barre({ pourcentage }: { pourcentage: number }) {
  return (
    <div aria-hidden className="h-2 overflow-hidden rounded-full bg-muted">
      <div
        className="h-full rounded-full bg-[var(--espace-accent)]"
        style={{ width: `${Math.max(0, Math.min(100, pourcentage))}%` }}
      />
    </div>
  );
}

type KpiProps = {
  icone: LucideIcon;
  libelle: string;
  valeur: string | null;
  detail?: string;
  chargement: boolean;
  erreur: boolean;
  onReessayer: () => void;
};

function Kpi({ icone: Icone, libelle, valeur, detail, chargement, erreur, onReessayer }: KpiProps) {
  return (
    <Carte>
      <div className="flex items-center gap-3">
        <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-muted text-foreground/70">
          <Icone className="size-4.5" aria-hidden />
        </span>
        <h2 className="text-sm text-muted-foreground">{libelle}</h2>
      </div>
      <div className="mt-3">
        {chargement ? (
          <>
            <Squelette className="h-8 w-16" />
            <Squelette className="mt-2 h-3.5 w-32" />
          </>
        ) : erreur ? (
          <ErreurBloc onReessayer={onReessayer} />
        ) : (
          <>
            <p className="text-3xl font-semibold tabular-nums">{valeur}</p>
            {detail && <p className="mt-1 text-xs text-muted-foreground">{detail}</p>}
          </>
        )}
      </div>
    </Carte>
  );
}

// ---- Tableau de bord --------------------------------------------------------

export function TableauDeBord() {
  const { profil } = useEspace();
  const peut = (permission: string) => profil.permissions.includes(permission);

  const voirUtilisateurs = peut("utilisateurs.gerer");
  const voirDepartements = peut("utilisateurs.departements");
  const voirModules = peut("personnalisation.modules");

  // Brouillons : seulement les types que ce rôle peut publier, dans un module actif
  const typesPublies = useMemo(
    () =>
      TYPES_CONTENU.filter(
        (t) => profil.modules_actifs.includes(t.module) && profil.permissions.includes(`${t.module}.publier`),
      ),
    [profil],
  );
  const voirBrouillons = typesPublies.length > 0;

  const chargerUtilisateurs = useCallback(async (token: string) => {
    // Les listes sont paginées : le total suffit, on ne lit pas les lignes
    const [actifs, inactifs] = await Promise.all([
      api<PageTotal>("/utilisateurs?statut=actif", { token }),
      api<PageTotal>("/utilisateurs?statut=inactif", { token }),
    ]);
    return { actifs: actifs.total, inactifs: inactifs.total };
  }, []);

  const chargerDepartements = useCallback((token: string) => api<DepartementResume[]>("/departements", { token }), []);
  const chargerModules = useCallback((token: string) => api<ModuleEtat[]>("/modules", { token }), []);

  const chargerBrouillons = useCallback(
    async (token: string) => {
      const reponses = await Promise.allSettled(
        typesPublies.map((t) => api<PageTotal>(`/contenus/${t.type}?statut=brouillon`, { token })),
      );
      if (reponses.every((r) => r.status === "rejected")) throw new Error("brouillons indisponibles");
      // Un type qui échoue s'affiche « — » plutôt qu'un 0 trompeur
      return typesPublies.map((t, i) => {
        const r = reponses[i];
        return { libelle: t.libelle, total: r.status === "fulfilled" ? r.value.total : null };
      });
    },
    [typesPublies],
  );

  const utilisateurs = useDonnees(voirUtilisateurs, chargerUtilisateurs);
  const departements = useDonnees(voirDepartements, chargerDepartements);
  const modules = useDonnees(voirModules, chargerModules);
  const brouillons = useDonnees(voirBrouillons, chargerBrouillons);

  const aujourdhui = format(new Date(), "EEEE d MMMM yyyy", { locale: fr });

  const nbModulesActifs = modules.donnees?.filter((m) => m.actif).length ?? 0;
  const nbObligatoires = modules.donnees?.filter((m) => m.module_obligatoire).length ?? 0;
  const nbEmployesRattaches = departements.donnees?.reduce((somme, d) => somme + d.nb_employes, 0) ?? 0;
  const totalBrouillons = brouillons.donnees?.reduce((somme, b) => somme + (b.total ?? 0), 0) ?? 0;

  const rienAAfficher = !voirUtilisateurs && !voirDepartements && !voirModules && !voirBrouillons;

  const departementsTries = [...(departements.donnees ?? [])].sort((a, b) => b.nb_employes - a.nb_employes).slice(0, 6);
  const maxEmployes = Math.max(1, ...departementsTries.map((d) => d.nb_employes));
  const maxBrouillons = Math.max(1, ...(brouillons.donnees ?? []).map((b) => b.total ?? 0));
  const modulesTries = [...(modules.donnees ?? [])].sort(
    (a, b) => Number(b.actif) - Number(a.actif) || a.nom_module.localeCompare(b.nom_module, "fr"),
  );

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight">Bonjour, {profil.prenom}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {profil.entreprise} · {profil.role} ·{" "}
          <span className="inline-block first-letter:uppercase">{aujourdhui}</span>
        </p>
      </header>

      {rienAAfficher && (
        <Carte>
          <p className="text-sm text-muted-foreground">
            Votre rôle ne comporte pas d&apos;outil d&apos;administration pour le moment.
          </p>
        </Carte>
      )}

      {(voirUtilisateurs || voirDepartements || voirModules || voirBrouillons) && (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {voirUtilisateurs && (
            <Kpi
              icone={Users}
              libelle="Comptes actifs"
              valeur={utilisateurs.donnees ? nombre.format(utilisateurs.donnees.actifs) : null}
              detail={
                utilisateurs.donnees
                  ? utilisateurs.donnees.inactifs === 0
                    ? "Aucun compte désactivé"
                    : `${nombre.format(utilisateurs.donnees.inactifs)} compte(s) désactivé(s)`
                  : undefined
              }
              chargement={utilisateurs.chargement}
              erreur={utilisateurs.erreur}
              onReessayer={utilisateurs.reessayer}
            />
          )}
          {voirDepartements && (
            <Kpi
              icone={Building2}
              libelle="Départements"
              valeur={departements.donnees ? nombre.format(departements.donnees.length) : null}
              detail={
                departements.donnees ? `${nombre.format(nbEmployesRattaches)} employé(s) rattaché(s)` : undefined
              }
              chargement={departements.chargement}
              erreur={departements.erreur}
              onReessayer={departements.reessayer}
            />
          )}
          {voirModules && (
            <Kpi
              icone={Blocks}
              libelle="Modules actifs"
              valeur={modules.donnees ? `${nbModulesActifs} / ${modules.donnees.length}` : null}
              detail={modules.donnees ? `dont ${nbObligatoires} obligatoires` : undefined}
              chargement={modules.chargement}
              erreur={modules.erreur}
              onReessayer={modules.reessayer}
            />
          )}
          {voirBrouillons && (
            <Kpi
              icone={FileClock}
              libelle="Brouillons à publier"
              valeur={brouillons.donnees ? nombre.format(totalBrouillons) : null}
              detail={brouillons.donnees ? `sur ${typesPublies.length} type(s) de contenu` : undefined}
              chargement={brouillons.chargement}
              erreur={brouillons.erreur}
              onReessayer={brouillons.reessayer}
            />
          )}
        </div>
      )}

      {(voirDepartements || voirBrouillons) && (
        <div className="grid gap-4 lg:grid-cols-3">
          {voirDepartements && (
            <Carte className={voirBrouillons ? "lg:col-span-2" : "lg:col-span-3"}>
              <h2 className="text-sm font-medium">Employés par département</h2>
              <div className="mt-4">
                {departements.chargement ? (
                  <div className="space-y-4">
                    <Squelette className="h-8 w-full" />
                    <Squelette className="h-8 w-full" />
                    <Squelette className="h-8 w-full" />
                  </div>
                ) : departements.erreur ? (
                  <ErreurBloc onReessayer={departements.reessayer} />
                ) : departementsTries.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Aucun département n&apos;a encore été créé.</p>
                ) : (
                  <ul className="space-y-4">
                    {departementsTries.map((d) => (
                      <li key={d.id}>
                        <div className="mb-1.5 flex items-baseline justify-between gap-3 text-sm">
                          <span className="truncate font-medium">{d.nom_departement}</span>
                          <span className="shrink-0 tabular-nums text-muted-foreground">
                            {nombre.format(d.nb_employes)}
                          </span>
                        </div>
                        <Barre pourcentage={(d.nb_employes / maxEmployes) * 100} />
                        <p className="mt-1 text-xs text-muted-foreground">
                          {d.responsable
                            ? `Responsable : ${d.responsable.prenom} ${d.responsable.nom}`
                            : "Aucun responsable désigné"}
                        </p>
                      </li>
                    ))}
                  </ul>
                )}
                {(departements.donnees?.length ?? 0) > departementsTries.length && (
                  <p className="mt-4 text-xs text-muted-foreground">
                    Les {departementsTries.length} départements les plus peuplés sur {departements.donnees?.length}.
                  </p>
                )}
              </div>
            </Carte>
          )}

          {voirBrouillons && (
            <Carte className={voirDepartements ? undefined : "lg:col-span-3"}>
              <h2 className="text-sm font-medium">Contenus en brouillon</h2>
              <div className="mt-4">
                {brouillons.chargement ? (
                  <div className="space-y-4">
                    <Squelette className="h-8 w-full" />
                    <Squelette className="h-8 w-full" />
                  </div>
                ) : brouillons.erreur ? (
                  <ErreurBloc onReessayer={brouillons.reessayer} />
                ) : totalBrouillons === 0 ? (
                  <p className="text-sm text-muted-foreground">Aucun brouillon en attente de publication.</p>
                ) : (
                  <ul className="space-y-4">
                    {brouillons.donnees?.map((b) => (
                      <li key={b.libelle}>
                        <div className="mb-1.5 flex items-baseline justify-between gap-3 text-sm">
                          <span className="font-medium">{b.libelle}</span>
                          <span className="tabular-nums text-muted-foreground">
                            {b.total === null ? "—" : nombre.format(b.total)}
                          </span>
                        </div>
                        <Barre pourcentage={((b.total ?? 0) / maxBrouillons) * 100} />
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </Carte>
          )}
        </div>
      )}

      {voirModules && (
        <Carte>
          <h2 className="text-sm font-medium">Modules de l&apos;intranet</h2>
          <div className="mt-4">
            {modules.chargement ? (
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {Array.from({ length: 6 }, (_, i) => (
                  <Squelette key={i} className="h-14" />
                ))}
              </div>
            ) : modules.erreur ? (
              <ErreurBloc onReessayer={modules.reessayer} />
            ) : (
              <ul className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {modulesTries.map((m) => {
                  const Icone = iconeModule(m.code_module);
                  return (
                    <li
                      key={m.code_module}
                      className={cn("flex items-center gap-3 rounded-lg border p-3", !m.actif && "opacity-60")}
                    >
                      <span className="grid size-8 shrink-0 place-items-center rounded-md bg-muted">
                        <Icone className="size-4" aria-hidden />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{m.nom_module}</p>
                        <p className="truncate text-xs text-muted-foreground">
                          {m.module_obligatoire ? "Obligatoire" : m.actif ? "Activé" : "Désactivé"}
                        </p>
                      </div>
                      <span
                        className={cn(
                          "size-2 shrink-0 rounded-full",
                          m.actif ? "bg-[var(--espace-accent)]" : "bg-muted-foreground/40",
                        )}
                      >
                        <span className="sr-only">{m.actif ? "Actif" : "Inactif"}</span>
                      </span>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </Carte>
      )}
    </div>
  );
}
