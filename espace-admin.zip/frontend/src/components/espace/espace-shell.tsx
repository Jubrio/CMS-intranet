"use client";

import { useEffect, useState, type CSSProperties, type ReactNode } from "react";
import { LogOut, Menu, X } from "lucide-react";
import { COULEUR_PAR_DEFAUT, couleurTexte, couleurValide, initiales } from "@/lib/espace";
import { Button } from "@/components/ui/button";
import { useEspace } from "./espace-context";
import { LogoEntreprise, Sidebar } from "./sidebar";

export function EspaceShell({ children }: { children: ReactNode }) {
  const { profil, perso, deconnecter } = useEspace();
  const [menuOuvert, setMenuOuvert] = useState(false);

  // Couleur principale de l'entreprise, avec vérification du format avant de l'injecter
  const accent = couleurValide(perso?.couleur_principale) ? perso.couleur_principale : COULEUR_PAR_DEFAUT;
  const variables = { "--espace-accent": accent, "--espace-accent-fg": couleurTexte(accent) } as CSSProperties;

  useEffect(() => {
    if (!menuOuvert) return;
    const surTouche = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOuvert(false);
    };
    window.addEventListener("keydown", surTouche);
    return () => window.removeEventListener("keydown", surTouche);
  }, [menuOuvert]);

  return (
    <div style={variables} className="flex min-h-screen flex-1 bg-muted/30">
      <a
        href="#contenu"
        className="sr-only z-50 rounded-md bg-background px-3 py-2 text-sm focus:not-sr-only focus:fixed focus:left-3 focus:top-3"
      >
        Aller au contenu
      </a>

      {/* Menu fixe (grands écrans) */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 border-r bg-sidebar lg:block">
        <Sidebar />
      </aside>

      {/* Menu en tiroir (petits écrans) */}
      {menuOuvert && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button
            type="button"
            aria-label="Fermer le menu"
            className="absolute inset-0 bg-black/40"
            onClick={() => setMenuOuvert(false)}
          />
          <aside className="absolute inset-y-0 left-0 w-72 max-w-[85vw] border-r bg-sidebar shadow-xl">
            <Button
              variant="ghost"
              size="icon-sm"
              className="absolute right-2 top-2.5"
              aria-label="Fermer le menu"
              onClick={() => setMenuOuvert(false)}
            >
              <X />
            </Button>
            <Sidebar onNavigate={() => setMenuOuvert(false)} />
          </aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b bg-background/85 px-4 backdrop-blur lg:px-8">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            aria-label="Ouvrir le menu"
            aria-expanded={menuOuvert}
            onClick={() => setMenuOuvert(true)}
          >
            <Menu />
          </Button>
          <div className="flex min-w-0 items-center gap-2 lg:hidden">
            <LogoEntreprise className="size-6 text-xs" />
            <span className="truncate text-sm font-semibold">{perso?.nom_entreprise ?? profil.entreprise}</span>
          </div>

          <div className="ml-auto flex items-center gap-3">
            <div className="hidden text-right leading-tight sm:block">
              <p className="text-sm font-medium">
                {profil.prenom} {profil.nom}
              </p>
              <p className="text-xs text-muted-foreground">{profil.role}</p>
            </div>
            <span
              aria-hidden
              className="grid size-8 place-items-center rounded-full bg-[var(--espace-accent)] text-xs font-semibold text-[var(--espace-accent-fg)]"
            >
              {initiales(profil.prenom, profil.nom)}
            </span>
            <Button variant="outline" size="sm" onClick={deconnecter}>
              <LogOut aria-hidden />
              <span className="hidden sm:inline">Se déconnecter</span>
              <span className="sr-only sm:hidden">Se déconnecter</span>
            </Button>
          </div>
        </header>

        <main id="contenu" className="flex-1 px-4 py-6 lg:px-8">
          <div className="mx-auto w-full max-w-6xl">{children}</div>
        </main>
      </div>
    </div>
  );
}
