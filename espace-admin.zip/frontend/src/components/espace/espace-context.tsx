"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { api, ApiError } from "@/lib/api";
import { effacerToken, lireToken } from "@/lib/session";
import type { Perso, Profil } from "@/lib/espace";
import { Button } from "@/components/ui/button";

type Valeur = {
  profil: Profil;
  perso: Perso | null;
  deconnecter: () => Promise<void>;
};

type Etat =
  | { statut: "chargement" }
  | { statut: "erreur" }
  | { statut: "pret"; profil: Profil; perso: Perso | null };

const Contexte = createContext<Valeur | null>(null);

export function useEspace(): Valeur {
  const v = useContext(Contexte);
  if (!v) throw new Error("useEspace doit être utilisé dans <EspaceProvider>.");
  return v;
}

// Vérifie la session, charge le profil et la personnalisation, puis n'affiche
// l'espace que lorsque tout est prêt. Sans jeton valide : retour à la connexion.
export function EspaceProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const [etat, setEtat] = useState<Etat>({ statut: "chargement" });
  const [essai, setEssai] = useState(0);

  useEffect(() => {
    const token = lireToken();
    if (!token) {
      router.replace("/connexion");
      return;
    }

    let annule = false;
    Promise.all([
      api<Profil>("/me", { token }),
      // La personnalisation est facultative : sans elle, on garde les valeurs par défaut
      api<Perso>("/personnalisation", { token }).catch(() => null),
    ])
      .then(([profil, perso]) => {
        if (!annule) setEtat({ statut: "pret", profil, perso });
      })
      .catch((err) => {
        if (annule) return;
        if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
          effacerToken();
          router.replace("/connexion");
          return;
        }
        setEtat({ statut: "erreur" });
      });

    return () => {
      annule = true;
    };
  }, [router, essai]);

  const deconnecter = useCallback(async () => {
    const token = lireToken();
    try {
      await api("/logout", { method: "POST", token });
    } catch {
      // le jeton local est supprimé dans tous les cas
    }
    effacerToken();
    router.replace("/");
  }, [router]);

  const valeur = useMemo<Valeur | null>(
    () => (etat.statut === "pret" ? { profil: etat.profil, perso: etat.perso, deconnecter } : null),
    [etat, deconnecter],
  );

  if (etat.statut === "chargement") {
    return (
      <main className="grid min-h-screen place-items-center text-sm text-muted-foreground" aria-busy="true">
        Chargement de votre espace…
      </main>
    );
  }

  if (etat.statut === "erreur") {
    return (
      <main className="grid min-h-screen place-items-center p-6">
        <div className="max-w-sm text-center">
          <p className="font-medium">Impossible de charger votre espace.</p>
          <p className="mt-1 text-sm text-muted-foreground">Vérifiez votre connexion, puis réessayez.</p>
          <Button
            className="mt-4"
            onClick={() => {
              setEtat({ statut: "chargement" });
              setEssai((n) => n + 1);
            }}
          >
            Réessayer
          </Button>
        </div>
      </main>
    );
  }

  // Compte sans entreprise (Super-administrateur) : cet espace est celui d'un intranet
  if (valeur && etat.statut === "pret" && etat.profil.entreprise === null) {
    return (
      <main className="grid min-h-screen place-items-center p-6">
        <div className="max-w-sm text-center">
          <p className="font-medium">Cet espace est réservé aux comptes d&apos;une entreprise.</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Le compte {etat.profil.email} n&apos;est rattaché à aucun intranet.
          </p>
          <Button className="mt-4" variant="outline" onClick={deconnecter}>
            Se déconnecter
          </Button>
        </div>
      </main>
    );
  }

  return <Contexte.Provider value={valeur}>{children}</Contexte.Provider>;
}
