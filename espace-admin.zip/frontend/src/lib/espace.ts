import {
  Building2,
  CalendarCheck,
  CircleHelp,
  ClipboardList,
  Contact,
  FileText,
  FolderOpen,
  LayoutDashboard,
  LayoutTemplate,
  ListTree,
  Megaphone,
  Newspaper,
  Palette,
  ScrollText,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  Users,
  type LucideIcon,
} from "lucide-react";

// Réponse de GET /api/me
export type Profil = {
  id: number;
  prenom: string;
  nom: string;
  email: string;
  role: string;
  entreprise: string | null;
  permissions: string[];
  modules_actifs: string[];
};

// Réponse de GET /api/personnalisation
export type Perso = {
  nom_entreprise: string;
  slug: string;
  email_contact: string | null;
  logo_url: string | null;
  couleur_principale: string;
  couleur_secondaire: string;
};

export type NavItem = {
  libelle: string;
  icone: LucideIcon;
  // Absent tant que l'écran n'est pas construit : l'entrée s'affiche en « Bientôt »
  href?: string;
  // Permission exigée (RG10) et modules qui doivent être actifs pour l'entreprise
  permission?: string;
  modules?: string[];
};

export type NavGroupe = { titre: string | null; items: NavItem[] };

export const NAV: NavGroupe[] = [
  {
    titre: null,
    items: [{ libelle: "Tableau de bord", icone: LayoutDashboard, href: "/espace" }],
  },
  {
    titre: "Organisation",
    items: [
      { libelle: "Utilisateurs", icone: Users, permission: "utilisateurs.gerer" },
      { libelle: "Départements", icone: Building2, permission: "utilisateurs.departements" },
      { libelle: "Rôles et permissions", icone: ShieldCheck, permission: "roles.gerer" },
    ],
  },
  {
    titre: "Contenus",
    items: [
      { libelle: "Actualités", icone: Newspaper, permission: "actualites.publier", modules: ["actualites"] },
      { libelle: "Annonces", icone: Megaphone, permission: "annonces.publier", modules: ["annonces"] },
      { libelle: "Articles", icone: FileText, permission: "articles.publier", modules: ["articles"] },
      { libelle: "Notes de service", icone: ScrollText, permission: "notes_service.publier", modules: ["notes_service"] },
      { libelle: "Pages internes", icone: LayoutTemplate, permission: "pages.gerer", modules: ["pages"] },
      { libelle: "Documents", icone: FolderOpen, permission: "documents.gerer", modules: ["documents"] },
      { libelle: "Événements", icone: CalendarCheck, permission: "evenements.gerer", modules: ["evenements", "calendrier"] },
      { libelle: "FAQ", icone: CircleHelp, permission: "faq.gerer", modules: ["faq"] },
      { libelle: "Formulaires", icone: ClipboardList, permission: "formulaires.gerer", modules: ["formulaires"] },
      { libelle: "Annuaire", icone: Contact, permission: "annuaire.gerer", modules: ["annuaire"] },
    ],
  },
  {
    titre: "Configuration",
    items: [
      { libelle: "Modules", icone: SlidersHorizontal, permission: "personnalisation.modules" },
      { libelle: "Apparence", icone: Palette, permission: "personnalisation.apparence" },
      { libelle: "Menus", icone: ListTree, permission: "personnalisation.parametres" },
      { libelle: "Paramètres", icone: Settings, permission: "personnalisation.parametres" },
    ],
  },
];

// Une entrée est visible si le rôle a la permission ET si les modules requis sont actifs
export function afficher(profil: Profil, item: NavItem): boolean {
  if (item.permission && !profil.permissions.includes(item.permission)) return false;
  if (item.modules && !item.modules.every((m) => profil.modules_actifs.includes(m))) return false;
  return true;
}

export const COULEUR_PAR_DEFAUT = "#1D4ED8";

export function couleurValide(c: string | null | undefined): c is string {
  return typeof c === "string" && /^#[0-9A-Fa-f]{6}$/.test(c);
}

// Texte lisible (noir ou blanc) sur la couleur principale choisie par l'entreprise
export function couleurTexte(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return 0.299 * r + 0.587 * g + 0.114 * b > 150 ? "#111827" : "#FFFFFF";
}

export function initiales(prenom: string, nom: string): string {
  return `${prenom.charAt(0)}${nom.charAt(0)}`.toUpperCase();
}
