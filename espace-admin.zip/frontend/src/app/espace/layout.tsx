import type { Metadata } from "next";
import type { ReactNode } from "react";
import { EspaceProvider } from "@/components/espace/espace-context";
import { EspaceShell } from "@/components/espace/espace-shell";

export const metadata: Metadata = {
  title: "Tableau de bord — CMS Intranet",
  robots: { index: false, follow: false },
};

export default function EspaceLayout({ children }: { children: ReactNode }) {
  return (
    <EspaceProvider>
      <EspaceShell>{children}</EspaceShell>
    </EspaceProvider>
  );
}
